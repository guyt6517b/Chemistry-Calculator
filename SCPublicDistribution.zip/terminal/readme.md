(c) 2025 Guyt6517
Educational use only. Not for resale without permission.

a scientific calculator that can be used to do practically
anything chemistry related

GenAI was used but credited, assume it isn't made with AI unless
otherwise stated.

files:

* conversions.txt: used by the MMUC, it defines how big a metric unit is

* terminal.py: is the main menu, keeps stuff nice and organized

* tc.py: Temperature conversions (Kelvin to Celsius, etc.)

* ppuc.py: version two of the pressure converter, partially used GenAI to generate 

* pt.py: Periodic Table of Elements, gives information on Elements

* mmuc.py: Converts metric units to other metric units

* im.py: Converts imperial American units to metric units