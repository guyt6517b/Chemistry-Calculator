def _():
    print(
        """
        Peroidic Table (PT)
        Data table generated with GenAi
        Isotope Stability finder generated with GenAi
        Bohr Model Animations generated with GenAi
        """
    )