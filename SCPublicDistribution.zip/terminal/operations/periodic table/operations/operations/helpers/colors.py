def _():
    veryHigh = '\033[91m' #Red
    high = '\033[93m' #Yellow
    moderate = '\033[94m' # Blue
    low = '\033[92m' #Green
    endc = '\033[0m'
    return veryHigh, high, moderate, low, endc