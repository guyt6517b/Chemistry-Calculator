import sys
import time
import os
import math
from operations.operations.helpers import callconversions, clearscreen, colors, printDisclaimer
from operations.operations.helpers.pyon import pyon
from operations.operations import bohrmodels, generalinfo, ioninfo, isotopeinfo, molarmass

printDisclaimer._()

global mapping